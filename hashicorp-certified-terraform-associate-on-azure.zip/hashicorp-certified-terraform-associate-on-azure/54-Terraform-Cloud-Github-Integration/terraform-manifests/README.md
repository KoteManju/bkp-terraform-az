# Terraform Cloud with Azure Usecase Demo

## Azure Demo on Terraform Cloud
- We are going to create the following Azure Resources
1. Azure Resource Group
2. Azure Virtual Network
3. Azure Subnet
4. Azure Public IP
5. Azure Network Interface
6. Azure Linux Virtual Machine
